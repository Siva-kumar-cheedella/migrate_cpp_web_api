import PostJobForm from "../components/PostJobForm";

const PostJob = () => {
  return (
    <div className="pt-40 px-32">
      <PostJobForm />
    </div>
  );
};

export default PostJob;
