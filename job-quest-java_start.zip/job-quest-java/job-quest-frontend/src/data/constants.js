export const qualificationOptions = [
  { value: "B.Tech", label: "B.Tech" },
  { value: "B.Sc", label: "B.Sc" },
  { value: "BCA", label: "BCA" },
  { value: "BA", label: "BA" },
  { value: "B.Com", label: "B.Com" },
  { value: "MBBS", label: "MBBS" },
  { value: "M.Tech", label: "M.Tech" },
  { value: "M.Sc", label: "M.Sc" },
  { value: "MCA", label: "MCA" },
  { value: "MA", label: "MA" },
  { value: "M.Com", label: "M.Com" },
  { value: "Others", label: "Others" },
];

export const skillOptions = [
  { value: "JavaScript", label: "JavaScript" },
  { value: "React", label: "React" },
  { value: "NodeJS", label: "NodeJS" },
  { value: "Java", label: "Java" },
  { value: "SpringBoot", label: "SpringBoot" },
  { value: "R", label: "R" },
  { value: "Python", label: "Python" },
  { value: "Jupyter Notebook", label: "Jupyter Notebook" },
  { value: "MATLAB", label: "MATLAB" },
  { value: "C/C++", label: "C/C++" },
];
